import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { Toaster } from '@/components/ui/toaster';
import ErrorBoundary from '@/components/ErrorBoundary';

// Pages
import Index from '@/pages/Index';
import Login from '@/pages/Login';
import OTPLogin from '@/pages/OTPLogin';
import RoleSelection from '@/pages/RoleSelection';
import FreelancerDashboard from '@/pages/FreelancerDashboard';
import ClientDashboard from '@/pages/ClientDashboard';
import AdminLogin from '@/pages/AdminLogin';
import AdminDashboard from '@/pages/AdminDashboard';
import AdminLayout from '@/pages/admin/AdminLayout';
import Services from '@/pages/Services';
import ServiceDetail from '@/pages/ServiceDetail';
import CreateService from '@/pages/CreateService';
import MyServices from '@/pages/MyServices';
import FreelancerOrderDashboard from '@/pages/FreelancerOrderDashboard';
import PostProject from '@/pages/PostProject';
import FreelancerProjects from '@/pages/FreelancerProjects';
import Messages from '@/pages/Messages';

// Components
import ProtectedRoute from '@/components/ProtectedRoute';

function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-white">
            <ErrorBoundary>
              <Routes>
                {/* Public Routes */}
                <Route path="/" element={<Index />} />
                <Route path="/login" element={<Login />} />
                <Route path="/otp-login" element={<OTPLogin />} />
                <Route path="/services" element={<Services />} />
                <Route path="/services/:id" element={<ServiceDetail />} />
                
                {/* Admin Routes */}
                <Route path="/admin/login" element={<AdminLogin />} />
                <Route 
                  path="/admin" 
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <AdminLayout />
                    </ProtectedRoute>
                  }
                >
                  <Route 
                    path="dashboard" 
                    element={
                      <ProtectedRoute requiredRole="admin">
                        <AdminDashboard />
                      </ProtectedRoute>
                    } 
                  />
                </Route>

                {/* Role Selection Route - Protected but doesn't require role selection */}
                <Route
                  path="/role-selection"
                  element={
                    <ErrorBoundary>
                      <ProtectedRoute requireRoleSelection={false}>
                        <RoleSelection />
                      </ProtectedRoute>
                    </ErrorBoundary>
                  }
                />

                {/* Messaging Route */}
                <Route
                  path="/messaging"
                  element={
                    <ProtectedRoute>
                      <Messages />
                    </ProtectedRoute>
                  }
                />

                {/* Freelancer Routes */}
                <Route
                  path="/freelancer/dashboard"
                  element={
                    <ProtectedRoute requiredRole="freelancer">
                      <FreelancerDashboard />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/dashboard/freelancer"
                  element={
                    <ProtectedRoute requiredRole="freelancer">
                      <FreelancerDashboard />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/freelancer/orders"
                  element={
                    <ProtectedRoute requiredRole="freelancer">
                      <FreelancerOrderDashboard />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/create-service"
                  element={
                    <ProtectedRoute requiredRole="freelancer">
                      <CreateService />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/my-services"
                  element={
                    <ProtectedRoute requiredRole="freelancer">
                      <MyServices />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/post-project"
                  element={
                    <ProtectedRoute requiredRole="freelancer">
                      <PostProject />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/freelancer-projects"
                  element={
                    <ProtectedRoute requiredRole="freelancer">
                      <FreelancerProjects />
                    </ProtectedRoute>
                  }
                />

                {/* Client Routes */}
                <Route
                  path="/client/dashboard"
                  element={
                    <ProtectedRoute requiredRole="client">
                      <ClientDashboard />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/dashboard/client"
                  element={
                    <ProtectedRoute requiredRole="client">
                      <ClientDashboard />
                    </ProtectedRoute>
                  }
                />

                {/* Redirect based on role */}
                <Route path="/dashboard" element={<Navigate to="/" replace />} />
                
                {/* Catch all route for 404 */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </ErrorBoundary>
            <Toaster />
          </div>
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;
